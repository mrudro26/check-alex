const tabButtons = document.querySelectorAll(".buttonContainer li button")
const pannel = document.querySelectorAll(".pannelContainer .tabPannel")

const showPannel = (index) => {
    tabButtons.forEach(function (node) {
        node.style.backgroundColor = ""
        node.style.color = ""
        
    })
    tabButtons[index].style.backgroundColor = "#ED7D23"
    tabButtons[index].style.color = "white"
    pannel.forEach(function (node) {
        node.style.display = "none"        
    })
    pannel[index].style.display = "block"        
}
showPannel(4)