const displayModal = document.getElementById('modalReading')

const continueReading = () => {
    displayModal.classList.remove('display-none')
}

const closeModal = () => {
    displayModal.classList.add('display-none')
}

const displayModal2 = document.getElementById('modalReading2')

const continueReading2 = () => {
    displayModal2.classList.remove('display-none')
}

const closeModal2 = () => {
    displayModal2.classList.add('display-none')
}